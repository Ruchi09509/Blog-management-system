<?php

$server = "localhost";
$user = "root";
$pass = "";
$dbname = "blog_system";

$conn = mysqli_connect($server,$user,$pass,$dbname);
if($conn == false){
    echo "not connected ".mysqli_connect_error();
}

?>