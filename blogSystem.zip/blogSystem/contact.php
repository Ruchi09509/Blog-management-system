<?php
session_start();
include("db.php");

$success = $error = "";

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);
    $blog_file = "";

    // Handle blog file upload
    if(isset($_FILES['blog_file']) && $_FILES['blog_file']['error'] == 0){
        $allowed_types = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        if(in_array($_FILES['blog_file']['type'], $allowed_types)){
            $blog_file = time() . "_" . $_FILES['blog_file']['name'];
            if(!move_uploaded_file($_FILES['blog_file']['tmp_name'], __DIR__ . "/uploads/" . $blog_file)){
                $error = "Failed to upload your blog file. Check folder permissions.";
            }
        } else {
            $error = "Invalid file type. Only PDF or Word files are allowed.";
        }
    }

    // Insert into database if no error
    if($error == ""){
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, subject, message, blog_file) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $email, $subject, $message, $blog_file);
        if($stmt->execute()){
            $success = "Thank you! Your message has been sent.";
        } else {
            $error = "Failed to submit your message. Please try again.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact Us - Blog Villa</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <?php 
    include("header.php");
    ?>

<div class="max-w-3xl mx-auto p-6 bg-white shadow mt-10 rounded">
    <h1 class="text-3xl font-bold mb-6">Contact Us</h1>

    <?php if($success) echo "<p class='bg-green-100 text-green-800 p-3 mb-4 rounded'>$success</p>"; ?>
    <?php if($error) echo "<p class='bg-red-100 text-red-800 p-3 mb-4 rounded'>$error</p>"; ?>

    <form method="POST" enctype="multipart/form-data" class="space-y-4">
        <input type="text" name="name" placeholder="Your Name" required class="w-full px-4 py-2 border rounded">
        <input type="email" name="email" placeholder="Your Email" required class="w-full px-4 py-2 border rounded">
        <input type="text" name="subject" placeholder="Subject" required class="w-full px-4 py-2 border rounded">
        <textarea name="message" placeholder="Your Message" required class="w-full px-4 py-2 border rounded h-32"></textarea>
        <label class="block">
            <span>Attach Your Blog (optional, PDF/Word)</span>
            <input type="file" name="blog_file" class="mt-2">
        </label>
        <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-800">Send Message</button>
    </form>
</div>

</body>
</html>
