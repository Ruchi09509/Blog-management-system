<?php
ob_start(); 
session_start();
include(__DIR__ . "/db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'] ?? 'user';
$pageRaw = $_GET['page'] ?? 'dashboard';
// sanitize page name
$page = preg_replace('/[^a-z0-9_]/i','', $pageRaw);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Blog Villa Panel</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

<!-- Header -->
<header class="bg-[rgb(96,125,139)] text-white shadow-md sticky top-0 z-50">
    <div class="container mx-auto flex justify-between items-center p-4">
        <div class="flex items-center gap-4">
            <img src="../logo.png" alt="logo" class="w-12 h-12 object-contain rounded" />
            <h1 class="text-2xl font-bold">Blog Villa </h1>
        </div>
        <div class="flex items-center gap-4">
            <div class="text-sm">Welcome, <strong><?= htmlspecialchars($_SESSION['name'] ?? 'User') ?></strong> (<?= htmlspecialchars($role) ?>)</div>
            <a href="logout.php" class="px-4 py-2 bg-red-600 rounded hover:bg-red-700">Logout</a>
        </div>
    </div>
</header>

<div class="flex h-[calc(100vh-64px)]">

    <!-- Sidebar -->
    <aside class="w-64 bg-white shadow-md hidden md:block overflow-y-auto">
        <nav class="p-4 space-y-2">

            <!-- Dashboard (both roles) -->
            <a href="admin_panel.php?page=dashboard" 
               class="block p-2 rounded hover:bg-violet-100 <?= $page=='dashboard'?'bg-violet-200 font-semibold':'' ?>">Dashboard</a>

            <!-- Blogs -->
            <div>
                <button onclick="toggleDropdown('blogsMenu')" class="w-full flex items-center justify-between p-2 rounded hover:bg-violet-100 <?= in_array($page, ['blog','add_blog','edit_blog'])?'bg-violet-200 font-semibold':'' ?>">
                    <span>Blogs</span><span id="blogsArrow">▼</span>
                </button>
                <div id="blogsMenu" class="ml-4 mt-1 text-sm <?= in_array($page, ['blog','add_blog','edit_blog'])?'':'hidden' ?>">
                    <a href="admin_panel.php?page=blog" class="block p-2 rounded hover:bg-gray-100 <?= $page=='blog'?'bg-gray-200':'' ?>">Show Blogs</a>
                    <?php if($role==='admin'): ?>
                        <a href="admin_panel.php?page=add_blog" class="block p-2 rounded hover:bg-gray-100 <?= $page=='add_blog'?'bg-gray-200':'' ?>">Add Blog</a>
                        <a href="admin_panel.php?page=edit_blog" class="block p-2 rounded hover:bg-gray-100 <?= $page=='edit_blog'?'bg-gray-200':'' ?>">Edit Blog</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Categories -->
            <div>
                <button onclick="toggleDropdown('categoriesMenu')" class="w-full flex items-center justify-between p-2 rounded hover:bg-violet-100 <?= in_array($page, ['categories','add_category','edit_category'])?'bg-violet-200 font-semibold':'' ?>">
                    <span>Categories</span><span id="categoriesArrow">▼</span>
                </button>
                <div id="categoriesMenu" class="ml-4 mt-1 text-sm <?= in_array($page, ['categories','add_category','edit_category'])?'':'hidden' ?>">
                    <a href="admin_panel.php?page=categories" class="block p-2 rounded hover:bg-gray-100 <?= $page=='categories'?'bg-gray-200':'' ?>">Show Categories</a>
                    <?php if($role==='admin'): ?>
                        <a href="admin_panel.php?page=add_category" class="block p-2 rounded hover:bg-gray-100 <?= $page=='add_category'?'bg-gray-200':'' ?>">Add Category</a>
                        <a href="admin_panel.php?page=edit_category" class="block p-2 rounded hover:bg-gray-100 <?= $page=='edit_category'?'bg-gray-200':'' ?>">Edit Category</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Users (admin only) -->
            <?php if($role==='admin'): ?>
            <div>
                <button onclick="toggleDropdown('usersMenu')" class="w-full flex items-center justify-between p-2 rounded hover:bg-violet-100 <?= in_array($page, ['users','add_users','edit_users','showBlock_users'])?'bg-violet-200 font-semibold':'' ?>">
                    <span>Users</span><span id="usersArrow">▼</span>
                </button>
                <div id="usersMenu" class="ml-4 mt-1 text-sm <?= in_array($page, ['users','add_users','edit_users','showBlock_users'])?'':'hidden' ?>">
                    <a href="admin_panel.php?page=users" class="block p-2 rounded hover:bg-gray-100 <?= $page=='users'?'bg-gray-200':'' ?>">Show Users</a>
                    <a href="admin_panel.php?page=add_users" class="block p-2 rounded hover:bg-gray-100 <?= $page=='add_users'?'bg-gray-200':'' ?>">Add Users</a>
                    <a href="admin_panel.php?page=edit_users" class="block p-2 rounded hover:bg-gray-100 <?= $page=='edit_users'?'bg-gray-200':'' ?>">Edit Users</a>
                    <a href="admin_panel.php?page=showBlock_users" class="block p-2 rounded hover:bg-gray-100 <?= $page=='showBlock_users'?'bg-gray-200':'' ?>">Blocked Users</a>
                </div>
            </div>
            <?php endif; ?>

            <!-- Shared Posts (both) -->
            <a href="admin_panel.php?page=shared_post" class="block p-2 rounded hover:bg-violet-100 <?= $page=='shared_post'?'bg-violet-200 font-semibold':'' ?>">Shared Post</a>

           <!-- comments Posts (admin) -->
            <?php if($role==='admin'): ?>
            <a href="admin_panel.php?page=comments" class="block p-2 rounded hover:bg-violet-100 <?= $page=='comments'?'bg-violet-200 font-semibold':'' ?>">comments</a>
            <?php endif; ?>

            <!-- blog add (user) -->
             <?php if($role==='user'): ?>
            <a href="admin_panel.php?page=blog_add" class="block p-2 rounded hover:bg-violet-100 <?= $page=='blog_add'?'bg-violet-200 font-semibold':'' ?>">Blog writing</a>
            <?php endif; ?>

            
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-6 overflow-y-auto">
        <?php
        if($role==='admin') {
            switch($page) {
                case 'dashboard': include __DIR__ . "/pages/dashboard.php"; break;
                case 'blog': include __DIR__ . "/pages/blog.php"; break;
                case 'add_blog': include __DIR__ . "/pages/add_blog.php"; break;
                case 'edit_blog': include __DIR__ . "/pages/edit_blog.php"; break;
                case 'delete_blog': include __DIR__ . "/pages/delete_blog.php"; break;
                case 'categories': include __DIR__ . "/pages/categories.php"; break;
                case 'add_category': include __DIR__ . "/pages/add_category.php"; break;
                case 'edit_category': include __DIR__ . "/pages/edit_category.php"; break;
                case 'delete_category': include __DIR__ . "/pages/delete_category.php"; break;
                case 'users': include __DIR__ . "/pages/users.php"; break;
                case 'add_users': include __DIR__ . "/pages/add_users.php"; break;
                case 'edit_users': include __DIR__ . "/pages/edit_users.php"; break;
                case 'block_users': include __DIR__ . "/pages/block_users.php"; break;
                case 'showBlock_users': include __DIR__ . "/pages/showBlock_users.php"; break;
                case 'unblock_users': include __DIR__ . "/pages/unblock_users.php"; break;
                case 'shared_post': include __DIR__ . "/pages/shared_post.php"; break;
                case 'comments': include __DIR__ . "/pages/comments.php"; break;
                default: echo "<h2 class='text-xl font-bold'>Page Not Found</h2>";
            }
        }
        elseif($role==='user') {
            switch($page) {
                case 'dashboard':
                    echo "<h2 class='text-2xl font-bold mb-4'>Welcome to your panel</h2>";
                    echo "<p>As a user you can view blogs, categories, and shared posts.</p>";
                    break;
                case 'blog': include __DIR__ . "/pages/blog.php"; break;
                case 'categories': include __DIR__ . "/pages/categories.php"; break;
                case 'shared_post': include __DIR__ . "/pages/shared_post.php"; break;
                case 'blog_add': include __DIR__ . "/pages/blog_add.php"; break;
                default:
                    echo "<div class='bg-red-50 border border-red-200 text-red-700 p-4 rounded'>You are not authorized to view this page.</div>";
            }
        } else {
            echo "<h2 class='text-xl font-bold'>Unknown role</h2>";
        }
        ?>
    </main>

</div>

<!-- JS for dropdown -->
<script>
function toggleDropdown(menuId) {
    const menu = document.getElementById(menuId);
    const arrow = document.getElementById(menuId.replace('Menu','Arrow'));
    if(!menu) return;
    menu.classList.toggle('hidden');
    arrow && (arrow.textContent = menu.classList.contains('hidden') ? '▼' : '▲');
}
</script>

</body>
</html>
