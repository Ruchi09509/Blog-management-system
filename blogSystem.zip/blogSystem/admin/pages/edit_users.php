<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");
if (!isset($_GET['id'])) {
    echo "User ID missing";
    exit();
}

$user_id = $_GET['id'];

$sql = "SELECT * FROM users WHERE user_id = '$user_id'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

if (!$user) {
    echo "User not found";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $image_name = $post['image'];

    // Handle image upload if new image selected
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0){
        $image_name = time() . "_" . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], __DIR__ . "/../../uploads/" . $image_name);
    }


    $stmt = $conn->prepare("UPDATE users SET name=?, email=?, password=? image=? WHERE user_id=?");
    $stmt->bind_param("sssi", $name, $email, $hashed, $image_name, $user_id);
    $stmt->execute();
    $stmt->close();

    header("Location: ../admin/admin_panel.php?page=users");
    exit();
}
?>
<h2 class="text-2xl font-bold mb-4">Update User</h2>

<form method="POST" enctype="multipart/form-data" class="space-y-4 max-w-lg">
  <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required class="w-full px-4 py-2 border rounded">
<input type="text" name="email" value="<?= htmlspecialchars($user['email']) ?>" required class="w-full px-4 py-2 border rounded">
<input type="password" name="password" placeholder="Update Password" class="w-full px-4 py-2 border rounded">
 <input type="file" name="image" required class="w-full px-4 py-2 border rounded">
 <p>Current Image:</p> <img src="../uploads/<?= $post['image'] ?>" width="120">

  <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-800">Update User</button>
</form>

