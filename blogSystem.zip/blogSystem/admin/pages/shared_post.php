<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");
?>

<h2 class="text-2xl font-bold mb-4">Shared Post</h2>

<table class="min-w-full border">
  <thead class="bg-gray-200">
    <tr>
      <th class="border px-4 py-2">ID</th>
      <th class="border px-4 py-2">Name</th>
      <th class="border px-4 py-2">Email</th>
      <th class="border px-4 py-2">Subject</th>
      <th class="border px-4 py-2">Message</th>
      <th class="border px-4 py-2">blog_file</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $sql = "SELECT * FROM contact_messages";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                <td class='border px-4 py-2'>{$row['contact_id']}</td>
                <td class='border px-4 py-2'>{$row['name']}</td>
                <td class='border px-4 py-2'>{$row['email']}</td>
                <td class='border px-4 py-2'>{$row['subject']}</td>
                <td class='border px-4 py-2'>{$row['message']}</td>
                <td class='border px-4 py-2'>{$row['blog_file']}</td>  
              </tr>";
        }
    } else {
        echo "<tr><td colspan='6' class='border px-4 py-2 text-center'>No blogs found</td></tr>";
    }
    ?>
  </tbody>
</table>
