<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");

if (!isset($_GET['id'])) {
    echo "Blog ID missing";
    exit();
}

$post_id = $_GET['id'];

// Fetch current blog data
$stmt = $conn->prepare("SELECT * FROM post WHERE post_id = ?");
$stmt->bind_param("i", $post_id);
$stmt->execute();
$result = $stmt->get_result();
$post = $result->fetch_assoc();
$stmt->close();

if (!$post) {
    echo "Blog not found";
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $title = trim($_POST['title']);
    $category_id = $_POST['category_id'];
    $about_us = trim($_POST['about_us']);
    $image_name = $post['image'];

    // Handle image upload if new image selected
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0){
        $image_name = time() . "_" . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], __DIR__ . "/../../uploads/" . $image_name);
    }

    $stmt = $conn->prepare("UPDATE post SET post_title=?, category_id=?, image=?, about_us=? WHERE post_id=?");
    $stmt->bind_param("sissi", $title, $category_id, $image_name, $about_us, $post_id);
    $stmt->execute();
    $stmt->close();

    header("Location: ../admin/admin_panel.php?page=blog");
    exit();
}

// Fetch categories
$cat_result = $conn->query("SELECT * FROM category ORDER BY category_name ASC");
?>

<h2 class="text-2xl font-bold mb-4">Edit Blog</h2>

<form method="POST" enctype="multipart/form-data" class="space-y-4 max-w-lg">
  <input type="text" name="title" value="<?= htmlspecialchars($post['post_title']) ?>" placeholder="Blog Title" required class="w-full px-4 py-2 border rounded">
  
  <select name="category_id" required class="w-full px-4 py-2 border rounded">
    <option value="">Select Category</option>
    <?php while($cat = $cat_result->fetch_assoc()): ?>
      <option value="<?= $cat['category_id'] ?>" <?= $cat['category_id']==$post['category_id']?'selected':'' ?>>
        <?= $cat['category_name'] ?>
      </option>
    <?php endwhile; ?>
  </select>

  <textarea name="about_us" placeholder="Content" required class="w-full px-4 py-2 border rounded"><?= htmlspecialchars($post['about_us']) ?></textarea>

  <input type="file" name="image" class="w-full px-4 py-2 border rounded">
  <p>Current Image:</p>
  <img src="../uploads/<?= $post['image'] ?>" width="120">

  <button type="submit" class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600">Update Blog</button>
</form>
