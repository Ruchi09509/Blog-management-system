<?php
include("../db.php");

$id = $_GET['id'] ?? null;

if (!$id) {
    echo "<p class='text-red-600'>Invalid category.</p>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $name = trim($_POST['name']);
    if (!empty($name)) {
        $stmt = $conn->prepare("UPDATE category SET category_name=? WHERE category_id=?");
        $stmt->bind_param("si", $name, $id);
        $stmt->execute();
        header("Location: ../admin/admin_panel.php?page=categories");
        exit();
    } else {
        $error = "Category name cannot be empty.";
    }
}

$sql = "SELECT * FROM category WHERE category_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$category = $stmt->get_result()->fetch_assoc();
?>

<h2 class="text-2xl font-bold mb-4">Edit Category</h2>
<form method="POST" class="space-y-4">
  <input type="text" name="name" value="<?= htmlspecialchars($category['category_name']) ?>" required
         class="w-full px-4 py-2 border rounded-lg">
  <button type="submit" 
          class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-800">
    Update
  </button>
</form>
<?php if (!empty($error)) echo "<p class='text-red-600 mt-2'>$error</p>"; ?>
