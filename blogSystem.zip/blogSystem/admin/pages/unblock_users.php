<?php
include("../db.php");

$id = $_GET['id'] ?? null;

if ($id) {
    $stmt = $conn->prepare("UPDATE users SET status=1 WHERE user_id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

header("Location: ../admin/admin_panel.php?page=showBlock_users");
exit();
