<?php
include("../db.php");

// Fetch all categories
$sql = "SELECT * FROM category ORDER BY category_id DESC";
$result = mysqli_query($conn, $sql);
?>

<h2 class="text-2xl font-bold mb-4">Categories</h2>
<a href="admin_panel.php?page=add_category" 
   class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-800 mb-4 inline-block">+ Add Category</a>

<table class="w-full border-collapse border border-gray-300">
  <thead>
    <tr class="bg-gray-100">
      <th class="border p-2">ID</th>
      <th class="border p-2">Name</th>
      <th class="border p-2">Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php while($row = mysqli_fetch_assoc($result)) { ?>
      <tr>
        <td class="border p-2"><?= $row['category_id'] ?></td>
        <td class="border p-2"><?= htmlspecialchars($row['category_name']) ?></td>
        <td class="border p-2">
          <a href="admin_panel.php?page=edit_category&id=<?= $row['category_id'] ?>" 
             class="text-blue-600">Edit</a> | 
          <a href="admin_panel.php?page=delete_category&id=<?= $row['category_id'] ?>" 
             class="text-red-600"
             onclick="return confirm('Are you sure you want to delete this category?');">Delete</a>
        </td>
      </tr>
    <?php } ?>
  </tbody>
</table>
