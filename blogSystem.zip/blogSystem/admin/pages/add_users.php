<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("../db.php");

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $hashed = password_hash($password, PASSWORD_DEFAULT);

    $image_name = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image_name = time() . "_" . basename($_FILES['image']['name']);
        $target_path = __DIR__ . "/../../uploads/" . $image_name;

        if (!move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
            die("Failed to upload image. Check permissions for uploads folder.");
        }
    }

    // Set default role
    $role = "user";

    $stmt = $conn->prepare("INSERT INTO users (name, email, password, image, role) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $hashed, $image_name, $role);
    $stmt->execute();
    $stmt->close();

    header("Location: ../admin/admin_panel.php?page=users");
    exit();
}
?>

<h2 class="text-2xl font-bold mb-4">Add New User</h2>

<form method="POST" enctype="multipart/form-data" class="space-y-4 max-w-lg">
  <input type="text" name="name" placeholder="User name" required class="w-full px-4 py-2 border rounded">
  <input type="email" name="email" placeholder="Enter email" required class="w-full px-4 py-2 border rounded">
  <input type="password" name="password" placeholder="Enter Password" required class="w-full px-4 py-2 border rounded">
  <input type="file" name="image" accept="image/*" class="w-full px-4 py-2 border rounded">
  
  <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-800">
    Add User
  </button>
</form>
