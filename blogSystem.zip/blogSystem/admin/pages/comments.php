<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");
?>

<h2 class="text-2xl font-bold mb-4">comments on post</h2>

<table class="min-w-full border">
  <thead class="bg-gray-200">
    <tr>
      <th class="border px-4 py-2">Name</th>
      <th class="border px-4 py-2">Email</th>
      <th class="border px-4 py-2">Comment</th> 
    </tr>
  </thead>
  <tbody>
    <?php
    $sql = "SELECT * FROM comments";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                <td class='border px-4 py-2'>{$row['name']}</td>
                <td class='border px-4 py-2'>{$row['email']}</td>
                <td class='border px-4 py-2'>{$row['comment']}</td>
              </tr>";
        }
    } else {
        echo "<tr><td colspan='6' class='border px-4 py-2 text-center'>No comments found</td></tr>";
    }
    ?>
  </tbody>
</table>
