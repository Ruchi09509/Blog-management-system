<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");
?>

<h2 class="text-2xl font-bold mb-4">All Users</h2>

<a href="admin_panel.php?page=add_users" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-800 mb-4 inline-block">
  Add New User
</a>

<table class="min-w-full border">
  <thead class="bg-gray-200">
    <tr>
      <th class="border px-4 py-2">ID</th>
      <th class="border px-4 py-2">Name</th>
      <th class="border px-4 py-2">Email</th>
      <th class="border px-4 py-2">Profile</th>
      <th class="border px-4 py-2">Status</th>
      <th class="border px-4 py-2">Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $sql = "SELECT * FROM users WHERE role='user' ";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                <td class='border px-4 py-2'>{$row['user_id']}</td>
                <td class='border px-4 py-2'>{$row['name']}</td>
                <td class='border px-4 py-2'>{$row['email']}</td>
                <td class='border px-4 py-2'><img src='/blogSystem/uploads/{$row['image']}' width='80' alt='User Image'></td>
                <td class='border px-4 py-2'>{$row['status']}</td>
                <td class='border px-4 py-2'>
                  <a href='admin_panel.php?page=edit_users&id={$row['user_id']}' class='bg-yellow-500 text-white px-2 py-1 rounded'>Edit</a>
                  <a href='admin_panel.php?page=delete_users&id={$row['user_id']}' class='bg-red-600 text-white px-2 py-1 rounded'>Delete</a>
                  <a href='admin_panel.php?page=block_users&id={$row['user_id']}' class='bg-blue-600 text-white px-2 py-1 rounded'>Block</a>
                </td>
              </tr>";
        }
    } else {
        echo "<tr><td colspan='6' class='border px-4 py-2 text-center'>No blogs found</td></tr>";
    }
    ?>
  </tbody>
</table>
