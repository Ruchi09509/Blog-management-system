<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");


?>

<h2 class="text-2xl font-bold mb-4">All Blogs</h2>

<table class="min-w-full border">
  <thead class="bg-gray-200">
    <tr>
      <th class="border px-4 py-2">ID</th>
      <th class="border px-4 py-2">Title</th>
      <th class="border px-4 py-2">Category</th>
      <th class="border px-4 py-2">Image</th>
      <th class="border px-4 py-2">Author</th>
      <th class="border px-4 py-2">Created Time</th>
      <th class="border px-4 py-2">Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $sql = "SELECT post.*, category.category_name 
            FROM post 
            JOIN category ON post.category_id = category.category_id 
            ORDER BY post.created_time DESC";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                <td class='border px-4 py-2'>{$row['post_id']}</td>
                <td class='border px-4 py-2'>{$row['post_title']}</td>
                <td class='border px-4 py-2'>{$row['category_name']}</td>
                <td class='border px-4 py-2'><img src='/blogSystem/uploads/{$row['image']}' width='80' alt='Blog Image'></td>
                <td class='border px-4 py-2'>{$row['author']}</td>
                <td class='border px-4 py-2'>{$row['created_time']}</td>
                <td class='border px-4 py-2'>
                  <a href='admin_panel.php?page=edit_blog&id={$row['post_id']}' class='bg-yellow-500 text-white px-2 py-1 rounded'>Edit</a>
                  <a href='admin_panel.php?page=delete_blog&id={$row['post_id']}' class='bg-red-600 text-white px-2 py-1 rounded'>Delete</a>
                </td>
              </tr>";
        }
    } else {
        echo "<tr><td colspan='6' class='border px-4 py-2 text-center'>No blogs found</td></tr>";
    }
    ?>
  </tbody>
</table>
