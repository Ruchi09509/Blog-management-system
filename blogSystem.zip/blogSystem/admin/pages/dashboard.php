<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");

// if (!isset($_SESSION['admin_id'])) {
    // header("Location: admin_login.php");
    // exit();
// }
?>

<h2 class="text-2xl font-bold mb-4">Admin Dashboard</h2>
<!-- Stats Cards -->
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    <!-- Total Users -->
    <div class="bg-white rounded-xl shadow-md p-6">
      <h3 class="text-gray-500 text-sm">Total Users</h3>
      <?php
        include("../db.php");
        $usersCount = $conn->query("SELECT COUNT(*) AS total FROM users where role='user' ")->fetch_assoc();
      ?>
      <p class="text-3xl font-bold text-violet-600"><?php echo $usersCount['total']; ?></p>
    </div>

    <!-- Total blogs -->
    <div class="bg-white rounded-xl shadow-md p-6">
      <h3 class="text-gray-500 text-sm">Total blogs</h3>
      <?php
        $blogsCount = $conn->query("SELECT COUNT(*) AS total FROM post")->fetch_assoc();
      ?>
      <p class="text-3xl font-bold text-green-600"><?php echo $blogsCount['total']; ?></p>
    </div>


   <!-- Total blogs -->
    <div class="bg-white rounded-xl shadow-md p-6">
      <h3 class="text-gray-500 text-sm">Total Categories</h3>
      <?php
        $categoriesCount = $conn->query("SELECT COUNT(*) AS total FROM category")->fetch_assoc();
      ?>
      <p class="text-3xl font-bold text-red-600"><?php echo $categoriesCount['total']; ?></p>
    </div>

    <!-- shared post -->
    <div class="bg-white rounded-xl shadow-md p-6">
      <h3 class="text-gray-500 text-sm">Shared Post</h3>
      <?php
        $messageCount = $conn->query("SELECT COUNT(*) AS total FROM contact_messages")->fetch_assoc();
      ?>
      <p class="text-3xl font-bold text-blue-600"><?php echo $messageCount['total']; ?></p>
    </div>

    <!-- comments on post -->
    <div class="bg-white rounded-xl shadow-md p-6">
      <h3 class="text-gray-500 text-sm">Total Comments</h3>
      <?php
        $commentCount = $conn->query("SELECT COUNT(*) AS total FROM comments")->fetch_assoc();
      ?>
      <p class="text-3xl font-bold text-yellow-600"><?php echo $commentCount['total']; ?></p>
    </div>

 </div>

 