<?php
include("../db.php");

$id = $_GET['id'] ?? null;

if ($id) {
    $stmt = $conn->prepare("DELETE FROM post WHERE post_id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

header("Location: ../admin/admin_panel.php?page=blog");
exit();
