<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include("../db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $title       = trim($_POST['title']);
    $category_id = intval($_POST['category_id']);
    $about_us    = trim($_POST['about_us']);
    $author      = trim($_POST['author']);
    $user_id     = $_SESSION['user_id']; 

   
    $image_name = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image_name = time() . "_" . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], __DIR__ . "/../../uploads/" . $image_name);
    }

    $stmt = $conn->prepare("INSERT INTO post (post_title, category_id, image, about_us, author, user_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisssi", $title, $category_id, $image_name, $about_us, $author, $user_id);
    $stmt->execute();
    $stmt->close();

    header("Location: ../admin/admin_panel.php?page=blog");
    exit();
}

$cat_result = $conn->query("SELECT * FROM category ORDER BY category_name ASC");
?>

<h2 class="text-2xl font-bold mb-4">Write a blog</h2>

<form method="POST" enctype="multipart/form-data" class="space-y-4 max-w-lg">
  <input type="text" name="title" placeholder="Blog Title" required class="w-full px-4 py-2 border rounded">
  
  <select name="category_id" required class="w-full px-4 py-2 border rounded">
    <option value="">Select Category</option>
    <?php while($cat = $cat_result->fetch_assoc()): ?>
      <option value="<?= $cat['category_id'] ?>"><?= $cat['category_name'] ?></option>
    <?php endwhile; ?>
  </select>

  <textarea name="about_us" placeholder="Content" required class="w-full px-4 py-2 border rounded"></textarea>

  <input type="file" name="image" required class="w-full px-4 py-2 border rounded">

  <input type="text" name="author" placeholder="author" required class="w-full px-4 py-2 border rounded">

  <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-800">Add Blog</button>
</form>
