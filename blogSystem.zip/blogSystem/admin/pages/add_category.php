<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");
$error = $error ?? '';
$success_message = $success_message ?? '';

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $name = trim($_POST['name']);

    if (!empty($name)) {
        $stmt = $conn->prepare("INSERT INTO category (category_name) VALUES (?)");
        $stmt->bind_param("s", $name);

        if ($stmt->execute()) {
           header("Location: ../admin/admin_panel.php?page=categories");
        exit();
            
        } else {
            $error = "Error adding category: " . $conn->error;
        }
    } else {
        $error = "Category name is required.";
    }
}
?>

<h2 class="text-2xl font-bold mb-4">Add Category</h2>

<?php if (!empty($success_message)): ?>
    <p class="bg-green-100 text-green-700 px-4 py-2 rounded mb-4"><?= htmlspecialchars($success_message) ?></p>
<?php endif; ?>

<?php if (!empty($error)): ?>
    <p class="bg-red-100 text-red-700 px-4 py-2 rounded mb-4"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

<form method="POST" class="space-y-4">
  <input type="text" name="name" placeholder="Category Name" required
         class="w-full px-4 py-2 border rounded-lg">
  <button type="submit" 
          class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-800">
    Save
  </button>
</form>
