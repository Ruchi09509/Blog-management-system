<?php
session_start();
include("../db.php");

$error = "";

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // fetch user from DB
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND status = 1 LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
    // Save session
    $_SESSION['user_id'] = $user['user_id'];
    $_SESSION['name'] = $user['name'];
    $_SESSION['role'] = $user['role'];

    if ($user['role'] === 'admin') {
        // Admin goes to admin panel
        header("Location: admin_panel.php");
        exit();
    } elseif ($user['role'] === 'user') {
        // Normal users go to user dashboard or home
        header("Location: admin_panel.php");
        exit();
    } else {
        $error = "Unknown role.";
    }

} else {
    $error = "Invalid password.";
}
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex items-center justify-center min-h-screen bg-gray-100">
  <div class="bg-white shadow-md rounded p-8 w-full max-w-md">
    <h2 class="text-2xl font-bold mb-6 text-center">Login</h2>
    
    <?php if ($error): ?>
      <p class="bg-red-100 text-red-600 px-4 py-2 rounded mb-4"><?php echo $error; ?></p>
    <?php endif; ?>

    <form method="POST" class="space-y-4">
      <input type="email" name="email" placeholder="Email" required class="w-full px-4 py-2 border rounded">
      <input type="password" name="password" placeholder="Password" required class="w-full px-4 py-2 border rounded">
      <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-800">Login</button>
    </form>
  </div>
</body>
</html>
