<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("db.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $comment = trim($_POST['comment']);

     $stmt = $conn->prepare("INSERT INTO comments (name, email, comment, created_time) VALUES ( ?, ?, ?, NOW())");
     $stmt->bind_param("sss", $name, $email, $comment);
     $stmt->execute();
     $stmt->close();
}
?>

<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>blog system</title> 
    <script src="https://cdn.tailwindcss.com"></script> 
</head> 

<body> 
<?php 
include("header.php");
?>    
<section class="container mx-auto p-6">
    <a href="blog.php" class="inline-block mb-4 text-sm text-purple-600 hover:underline">&larr; Back to Bloggers</a>
    <h2 class="text-3xl font-bold mb-6">Comment on Posts</h2>
    <form method="POST" class="mt-4 space-y-3 border-t pt-4"> 
        <input type="text" name="name" placeholder="Your Name" required class="w-full px-3 py-2 border rounded">
        <input type="text" name="email" placeholder="Your Email" required class="w-full px-3 py-2 border rounded"> 
        <textarea name="comment" placeholder="Your Comment" required class="w-full px-3 py-2 border rounded"></textarea> 
        <button type="submit" class="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"> Submit Comment </button> 
    </form> 
</section>  
</body> 
</html>
