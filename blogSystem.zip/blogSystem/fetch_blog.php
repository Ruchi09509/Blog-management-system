<?php
include("db.php");
include("header.php");


if (!isset($_GET['user_id']) || empty($_GET['user_id'])) {
    echo "<div class='container mx-auto p-6'><p class='text-center text-red-500'>No user selected.</p></div>";
    exit;
}

$user_id = intval($_GET['user_id']);


$stmt = $conn->prepare(
    "SELECT p.post_id, p.post_title, p.image AS post_image, p.about_us, p.author AS post_author, p.created_time,
            c.category_name, u.name AS user_name, u.image AS user_image
     FROM post p
     LEFT JOIN category c ON p.category_id = c.category_id
     LEFT JOIN users u ON p.user_id = u.user_id
     WHERE p.user_id = ?
     ORDER BY p.created_time DESC"
);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>User Blogs - Blog Villa</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
<section class="container mx-auto p-6">
  <a href="blog.php" class="inline-block mb-4 text-sm text-purple-600 hover:underline">&larr; Back to Bloggers</a>
  <h2 class="text-3xl font-bold mb-6">User's Posts</h2>

  <?php
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $title    = htmlspecialchars($row['post_title']);
            $postImg  = htmlspecialchars($row['post_image'] ?: 'default-post.jpg');
            $category = htmlspecialchars($row['category_name'] ?? 'Uncategorized');
            $author   = htmlspecialchars($row['user_name'] ?: $row['post_author'] ?: 'Unknown');
            $about    = nl2br(htmlspecialchars($row['about_us']));
            $post_id  = (int)$row['post_id'];

            echo '
            <div class="flex flex-col sm:flex-row gap-6 p-6 border rounded-lg shadow-md mb-6 bg-white">
                <!-- Left Side: Image -->
                <div class="sm:w-1/3">
                    <img class="w-full h-64 object-cover rounded-lg"
                         src="/blogSystem/uploads/' . $postImg . '"
                         alt="' . $title . '" />
                </div>

                <!-- Right Side: Content -->
                <div class="sm:w-2/3 flex flex-col justify-between">
                    <div class="space-y-2">
                        <p class="text-xl font-semibold text-black">Title: ' . $title . '</p>
                        <p class="text-sm text-gray-600">Category: ' . $category . '</p>
                        <p class="text-sm text-gray-600">Author: ' . $author . '</p>
                        <div class="mt-2 text-gray-700">' . $about . '</div>
                    </div>
                  <a href="save_comment.php">
                  <button class="mt-4 inline-block px-4 py-2 border border-purple-200 text-purple-600 rounded-lg text-center hover:border-transparent hover:bg-purple-600 hover:text-white active:bg-purple-700 transition">
                  Comment
                 </button>
                  </a>
              </div>
</div>';
        }
    } else {
        echo "<p class='text-center text-gray-500'>No posts found for this user</p>";
    }

    $stmt->close();
  ?>
</section>

<script>
function toggleCommentForm(postId) {
    const form = document.getElementById('comment-form-' + postId);
    form.classList.toggle('hidden');
}
</script>

</body>
</html>
