<?php
session_start();
include("db.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blog Villa</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

  <!-- Header -->
<?php
include("header.php");
?>
  <!-- Featured Posts -->
  <section class="container mx-auto p-6">
    <h2 class="text-3xl font-bold mb-6">Featured Posts</h2>
    <div class="grid md:grid-cols-3 gap-6">
      <?php
      // Fetch latest 6 posts
      $sql = "SELECT post.*, category.category_name 
              FROM post 
              JOIN category ON post.category_id = category.category_id 
              ORDER BY post.created_time DESC 
              LIMIT 6";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
              $imagePath = "uploads/" . $row['image'];
              if(!file_exists($imagePath)) {
                  $imagePath = "uploads/default.png"; // placeholder image if file not found
              }
              echo "<div class='bg-white rounded shadow-md overflow-hidden'>
                      <img src='{$imagePath}' alt='{$row['post_title']}' class='w-full h-48 object-cover'>
                      <div class='p-4'>
                        <h3 class='text-xl font-semibold mb-2'>{$row['post_title']}</h3>
                        <p class='text-sm text-gray-500 mb-2'>Category: {$row['category_name']}</p>
                        <p class='text-gray-700'>{$row['about_us']}</p>
                        <a href='blog.php?post_id={$row['post_id']}' class='text-indigo-600 mt-2 inline-block hover:underline'>Read More</a>
                      </div>
                    </div>";
          }
      } else {
          echo "<p class='col-span-3 text-center text-gray-600'>No posts found.</p>";
      }
      ?>
    </div>
  </section>

</body>
</html>
