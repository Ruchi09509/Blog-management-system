<?php
session_start();
include("db.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blog Villa</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
<?php
include("header.php");
?>
  <section class="container mx-auto p-6">
    <h2 class="text-3xl font-bold mb-6">Bloggers</h2>
    <div class="grid md:grid-cols-3 gap-6">

    <?php
$sql = "SELECT * FROM users WHERE role='user' ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '
        <div class="flex flex-col gap-3 p-8 sm:flex-row sm:items-center sm:gap-6 sm:py-4 border rounded-lg shadow-md mb-4 bg-white">
            <img class="mx-auto block h-24 w-24 rounded-full object-cover sm:mx-0 sm:shrink-0" 
                 src="/blogSystem/uploads/' . htmlspecialchars($row['image']) . '" 
                 alt="' . htmlspecialchars($row['name']) . '" />
            
            <div class="space-y-2 text-center sm:text-left">
                <div class="space-y-0.5">
                    <p class="text-lg font-semibold text-black">' . htmlspecialchars($row['name']) . '</p>
                </div>
                <a href="fetch_blog.php?user_id='.$row['user_id'].'" class="px-4 py-2 border border-purple-200 text-purple-600 rounded-lg hover:border-transparent hover:bg-purple-600 hover:text-white active:bg-purple-700 transition">
                    Blogs
                </a>
            </div>
        </div>';
    }
} else {
    echo "<p class='text-center text-gray-500'>No users found</p>";
}
?>
</body>
</html>
