<?php
include("db.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Blog Villa</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<!-- Header -->
<!-- Header -->
<header class="text-white sticky top-0 shadow-md z-50" style="background-color: rgb(96, 125, 139);">
  <div class="container mx-auto flex justify-between items-center p-4">
    
    <!-- Logo + Title -->
    <div class="flex items-center gap-4">
      <img src="logo.png" alt="logo" class="w-25 h-20 object-contain">
    </div>

    <!-- Navigation -->
    <nav class="flex items-center space-x-6 text-white font-medium">
      <a class="hover:text-gray-300 flex items-center gap-1" href="index.php">Home</a>
      <a class="hover:text-gray-300 flex items-center gap-1" href="blog.php">Blogs</a>
      <a class="hover:text-gray-300 flex items-center gap-1" href="contact.php">Contact</a>
      <a class="hover:text-gray-300 flex items-center gap-1" href="admin/login.php">login</a>
    </nav>

  </div>
</header>


</body>
</html>
